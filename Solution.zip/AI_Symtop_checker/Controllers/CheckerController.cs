﻿using Microsoft.AspNetCore.Mvc;
using AI_Symtop_checker.Services.Interfaces;

using AI_Symtop_checker.Model;
[ApiController]
[Route("api/[controller]")]
public class SymptomCheckerController : ControllerBase
{
    private readonly ISymptomCheckerService _service;
    private readonly ILogger<SymptomCheckerController> _logger;

    public SymptomCheckerController(ISymptomCheckerService service, ILogger<SymptomCheckerController> logger)
    {
        _service = service;
        _logger = logger;
    }

    [HttpPost("check")]
    public async Task<ActionResult<SymptomCheckPrediction>> CheckSymptomsAsync(List<string> symptoms)
    {
        try
        {
            var prediction = await _service.CheckSymptomsAsync(symptoms);
            return Ok(prediction);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid symptom check request");
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Symptom check processing error");
            return StatusCode(500, "Internal server error");
        }
    }
}
