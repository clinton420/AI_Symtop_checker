﻿// AI_Symtop_checker.ModelService/PythonModelService.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Python.Runtime;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Collections;

namespace AI_Symtop_checker.ModelService
{
    public class PythonModelService : IModelService, IDisposable
    {
        private readonly ILogger<PythonModelService> _logger;
        private static bool _isInitialized = false;
        private static readonly object _lockObj = new object();
        private bool _disposedValue;

        public PythonModelService(ILogger<PythonModelService> logger)
        {
            _logger = logger;
            Initialize();
        }

        private void Initialize()
        {
            if (!_isInitialized)
            {
                lock (_lockObj)
                {
                    if (!_isInitialized)
                    {
                        try
                        {
                            // Try to find Python installation using 'where python' command
                            string pythonPath = null;

                            var process = new System.Diagnostics.Process
                            {
                                StartInfo = new System.Diagnostics.ProcessStartInfo
                                {
                                    FileName = "where",
                                    Arguments = "python",
                                    UseShellExecute = false,
                                    RedirectStandardOutput = true,
                                    CreateNoWindow = true
                                }
                            };

                            process.Start();
                            string output = process.StandardOutput.ReadToEnd();
                            process.WaitForExit();

                            if (!string.IsNullOrEmpty(output))
                            {
                                // Take the first line which should be the main Python executable
                                string pythonExePath = output.Split(Environment.NewLine)[0].Trim();

                                if (!string.IsNullOrEmpty(pythonExePath) && File.Exists(pythonExePath))
                                {
                                    // Get the directory containing the Python executable
                                    string pythonDir = Path.GetDirectoryName(pythonExePath);

                                    _logger.LogInformation("Found Python at: {PythonDir}", pythonDir);

                                    // Find Python DLL in the same directory
                                    string[] possibleDlls = Directory.GetFiles(pythonDir, "python*.dll");

                                    if (possibleDlls.Length > 0)
                                    {
                                        // Prefer non-debug DLL
                                        pythonPath = possibleDlls.FirstOrDefault(p => !Path.GetFileName(p).Contains("_d.")) ?? possibleDlls[0];
                                    }
                                    else
                                    {
                                        // Check in the DLLs subfolder (common location)
                                        string dllsDir = Path.Combine(pythonDir, "DLLs");
                                        if (Directory.Exists(dllsDir))
                                        {
                                            possibleDlls = Directory.GetFiles(dllsDir, "python*.dll");
                                            if (possibleDlls.Length > 0)
                                            {
                                                pythonPath = possibleDlls.FirstOrDefault(p => !Path.GetFileName(p).Contains("_d.")) ?? possibleDlls[0];
                                            }
                                        }

                                        // Check in libs folder as a fallback
                                        if (pythonPath == null)
                                        {
                                            string libsDir = Path.Combine(pythonDir, "libs");
                                            if (Directory.Exists(libsDir))
                                            {
                                                possibleDlls = Directory.GetFiles(libsDir, "python*.dll");
                                                if (possibleDlls.Length > 0)
                                                {
                                                    pythonPath = possibleDlls.FirstOrDefault(p => !Path.GetFileName(p).Contains("_d.")) ?? possibleDlls[0];
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Fallback to environment variable if command failed
                            if (string.IsNullOrEmpty(pythonPath))
                            {
                                string pythonHome = Environment.GetEnvironmentVariable("PYTHONHOME");
                                if (!string.IsNullOrEmpty(pythonHome))
                                {
                                    _logger.LogInformation("Using PYTHONHOME: {PythonHome}", pythonHome);
                                    string[] possibleDlls = Directory.GetFiles(pythonHome, "python*.dll");
                                    if (possibleDlls.Length > 0)
                                    {
                                        pythonPath = possibleDlls.FirstOrDefault(p => !Path.GetFileName(p).Contains("_d.")) ?? possibleDlls[0];
                                    }
                                }
                            }

                            // Final fallback to a common location
                            if (string.IsNullOrEmpty(pythonPath))
                            {
                                _logger.LogWarning("Python not found through automatic detection, trying common locations");
                                string[] commonPaths = new[]
                                {
                                    @"C:\Python39\python39.dll",
                                    @"C:\Python310\python310.dll",
                                    @"C:\Python311\python311.dll",
                                    @"C:\Program Files\Python39\python39.dll",
                                    @"C:\Program Files\Python310\python310.dll",
                                    @"C:\Program Files\Python311\python311.dll"
                                };

                                foreach (var path in commonPaths)
                                {
                                    if (File.Exists(path))
                                    {
                                        pythonPath = path;
                                        break;
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(pythonPath))
                            {
                                throw new Exception("Python DLL not found. Please ensure Python is installed correctly.");
                            }

                            _logger.LogInformation("Using Python DLL: {PythonPath}", pythonPath);

                            Runtime.PythonDLL = pythonPath;
                            PythonEngine.Initialize();
                            PythonEngine.BeginAllowThreads();

                            _logger.LogInformation("Python runtime initialized successfully");
                            _isInitialized = true;
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "Failed to initialize Python runtime");
                            throw;
                        }
                    }
                }
            }
        }

        public async Task<ModelResponse> AnalyzeSymptomsAsync(ModelRequest request)
        {
            return await Task.Run(() =>
            {
                _logger.LogInformation("Analyzing symptoms: {Symptoms}", string.Join(", ", request.Symptoms));

                try
                {
                    using (Py.GIL())
                    {
                        // Add the script directory to Python path
                        dynamic sys = Py.Import("sys");
                        string scriptDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PythonScripts");
                        sys.path.append(scriptDir);

                        // Import the model module
                        dynamic modelModule = Py.Import("llama_model");

                        // Convert request data to Python
                        using PyList symptoms = new PyList();
                        foreach (var symptom in request.Symptoms)
                        {
                            symptoms.Append(new PyString(symptom));
                        }

                        // Call the analyze_symptoms function
                        dynamic result = modelModule.analyze_symptoms(
                            symptoms,
                            request.PatientAge ?? "",
                            request.PatientGender ?? "",
                            request.AdditionalNotes ?? ""
                        );

                        // Convert Python dictionary to string and then to .NET object
                        var resultDict = result.ToDictionary();
                        string jsonResult = JsonSerializer.Serialize(resultDict);
                        var parsedResult = JsonSerializer.Deserialize<Dictionary<string, object>>(jsonResult);

                        // Check for errors
                        if (parsedResult.ContainsKey("error"))
                        {
                            throw new Exception(parsedResult["error"].ToString());
                        }

                        // Map to response model
                        var response = new ModelResponse
                        {
                            Prediction = parsedResult["prediction"].ToString(),
                            Confidence = Convert.ToDouble(parsedResult["confidence"]),
                            UrgencyLevel = parsedResult["urgency_level"].ToString(),
                            AdditionalNotes = parsedResult["additional_notes"].ToString(),
                            Timestamp = DateTime.Parse(parsedResult["timestamp"].ToString())
                        };

                        // Process collections
                        var possibleConditions = JsonSerializer.Deserialize<List<string>>(
                            parsedResult["possible_conditions"].ToString()
                        );
                        response.PossibleConditions = possibleConditions;

                        var recommendedActions = JsonSerializer.Deserialize<List<string>>(
                            parsedResult["recommended_actions"].ToString()
                        );
                        response.RecommendedActions = recommendedActions;

                        return response;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error analyzing symptoms");
                    throw;
                }
            });
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    // No managed resources to dispose
                }

                // No unmanaged resources to dispose
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}